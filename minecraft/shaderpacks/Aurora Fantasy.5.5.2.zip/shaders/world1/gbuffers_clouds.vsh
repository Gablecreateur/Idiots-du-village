#version 120
/* Aurora Fantasy - gbuffers_clouds.vsh
Render: sky, clouds

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define THE_END
#define GBUFFER_CLOUDS
#define NO_SHADOWS

#include "/common/clouds_blocks_vertex.glsl"
