#version 120
/* Aurora Fantasy - gbuffers_basic.fsh
Render: Basic elements - lines

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define NETHER
#define GBUFFER_BASIC
#define NO_SHADOWS

#include "/common/basic_blocks_fragment.glsl"
