local default = require("tacz_default_state_machine")

local GUN_KICK_TRACK_LINE = default.GUN_KICK_TRACK_LINE
local STATIC_TRACK_LINE = default.STATIC_TRACK_LINE
local BLENDING_TRACK_LINE = default.BLENDING_TRACK_LINE
local BOLT_CAUGHT_TRACK = default.BOLT_CAUGHT_TRACK
local ADS_TRACK = default.ADS_TRACK
local MAIN_TRACK = default.MAIN_TRACK
local SPRINT_TRACK = default.SPRINT_TRACK
local MOVEMENT_TRACK = default.MOVEMENT_TRACK
local SLIDE_TRACK = default.SLIDE_TRACK

local main_track_states = default.main_track_states
local bolt_caught_states = default.bolt_caught_states
local movement_track_states = default.movement_track_states

local gun_kick_state = setmetatable({}, {__index = default.gun_kick_state})
local start_state = setmetatable({}, {__index = main_track_states.start})
local idle_state = setmetatable({}, {__index = main_track_states.idle})
local inspect_state = setmetatable({}, {__index = main_track_states.inspect})
local final_state = setmetatable({}, {__index = main_track_states.final})
local charge_state = {
    can_charge = true
}
local sweep_state = {}
local fast_reload_state = {}
local manual_reload_state = {
    -- reload_tactical 长 4.8333 秒；新弹巢在动画中点装入。
    tactical_visual_fill_delay = 2417,
    tactical_visual_fill_at = -1,
    ammo_before_reload = 0
}
local animation_controller_state = {
    last_animation_state = -1,
    last_shot_serial = 0,
    applied_animation_state = 0
}
local movement_idle_state = setmetatable({}, {__index = movement_track_states.idle})
local movement_run_state = setmetatable({mode = -1, time = 0}, {__index = movement_track_states.run})
local movement_walk_state = setmetatable({mode = -1}, {__index = movement_track_states.walk})
local normal = setmetatable({}, {__index = bolt_caught_states.normal})
local bolt_caught = setmetatable({}, {__index = bolt_caught_states.bolt_caught})

local function isNoAmmo(context)
    return (not context:hasBulletInBarrel()) and (context:getAmmoCount() <= 0)
end

local function runPutAwayAnimation(context)
    local put_away_time = context:getPutAwayTime()
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    context:runAnimation("put_away", track, false, PLAY_ONCE_HOLD, put_away_time * 0.75)
    context:setAnimationProgress(track, 1, true)
    context:adjustAnimationProgress(track, -put_away_time, false)
end

local function getScoreInt(context, score)
    local success, value = pcall(function()
        return context:getPlayerScoreInt(score)
    end)
    if not success then
        return 0
    end
    return value
end

local function getAnimationState(context)
    return getScoreInt(context, "%Var_BuerAnimationState%")
end

local function stopBlockedOverlayAnimations(context)
    context:stopAnimation(context:getTrack(BLENDING_TRACK_LINE, SLIDE_TRACK))
    context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, ADS_TRACK))
    context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SPRINT_TRACK))
end

local function stopExclusiveAnimations(context)
    context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
    stopBlockedOverlayAnimations(context)
end

local function selectAnimationState(this, context)
    local state = getAnimationState(context)
    if state == 1 then
        return this.main_track_states.buer_sweep
    elseif state == 2 then
        return this.main_track_states.buer_fast_reload
    end
    animation_controller_state.applied_animation_state = 0
    return this.main_track_states.idle
end

local function isSpecialAnimationActive(context)
    return getAnimationState(context) ~= 0
end

local function runNormalReloadAnimation(context)
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    context:stopAnimation(track)
    if isNoAmmo(context) then
        context:runAnimation("reload_empty", track, false, PLAY_ONCE_STOP, 0.1)
    else
        context:runAnimation("reload_tactical", track, false, PLAY_ONCE_STOP, 0.1)
    end
end

-- 普通射击仍使用完整的 shoot 动画；横扫的逐发 shoot2 由下方 Lua 控制器
-- 根据技能同步的序号播放，技能 YAML 不再直接操作任何动画轨道。
function gun_kick_state.transition(this, context, input)
    if (input == INPUT_SHOOT) then
        local track = context:findIdleTrack(GUN_KICK_TRACK_LINE, false)
        context:runAnimation("shoot", track, true, PLAY_ONCE_STOP, 0)
    end
    return nil
end

function start_state.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        return this.main_track_states.final
    end
    return main_track_states.start.transition(this, context, input)
end

function final_state.entry(this, context)
    -- 所有状态先完成 exit，再统一从 final 入口播放标准收枪动画。
    runPutAwayAnimation(context)
end

-- 双动扳机：枪械 data 中的 charging.semi 驱动 context:isCharging()。
-- 按住扳机时先播放 charge_in，达到阈值后 TacZ 产生 INPUT_SHOOT；
-- 提前松开则播放 charge_out，让击锤和弹巢回到待机位置。
function idle_state.update(this, context)
    if (context:isCharging()) then
        if (charge_state.can_charge) then
            context:trigger(this.INPUT_CHARING)
        end
    else
        charge_state.can_charge = true
    end

    if (main_track_states.idle.update) then
        main_track_states.idle.update(this, context)
    end
end

function idle_state.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        return this.main_track_states.final
    end

    if input == this.INPUT_BUER_ANIMATION_SYNC then
        return selectAnimationState(this, context)
    end

    if (input == INPUT_RELOAD) then
        return this.main_track_states.buer_manual_reload
    end

    -- 近战输入只由技能端判定是否成功；Lua 等待同步后的动画状态，避免技能
    -- 处于冷却或没有弹药时误播横扫。
    if (input == INPUT_BAYONET_MUZZLE or input == INPUT_BAYONET_STOCK or input == INPUT_BAYONET_PUSH) then
        return this.main_track_states.idle
    end

    if (input == this.INPUT_CHARING) then
        context:runAnimation("charge_in", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_HOLD, 0)
        return this.main_track_states.charge
    end

    return main_track_states.idle.transition(this, context, input)
end


function charge_state.update(this, context)
    if (not context:isCharging()) then
        charge_state.can_charge = true
        context:trigger(this.INPUT_CHARING_EXIT)
    end
end

function charge_state.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        return this.main_track_states.final
    end

    if input == this.INPUT_BUER_ANIMATION_SYNC then
        return selectAnimationState(this, context)
    end

    if (input == INPUT_SHOOT) then
        context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
        charge_state.can_charge = false
        return this.main_track_states.idle
    end
    if (input == this.INPUT_CHARING_EXIT) then
        context:runAnimation("charge_out", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_STOP, 0.3)
        return this.main_track_states.idle
    end
end

function inspect_state.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        return this.main_track_states.final
    end

    if input == this.INPUT_BUER_ANIMATION_SYNC then
        return selectAnimationState(this, context)
    end
    return main_track_states.inspect.transition(this, context, input)
end

function sweep_state.entry(this, context)
    stopExclusiveAnimations(context)
    animation_controller_state.applied_animation_state = 1
    context:runAnimation("sweepshoot", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_HOLD, 0)
end

function sweep_state.update(this, context)
    if getAnimationState(context) ~= 1 then
        context:trigger(this.INPUT_BUER_ANIMATION_SYNC)
    else
        stopBlockedOverlayAnimations(context)
    end
end

function sweep_state.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        return this.main_track_states.final
    elseif input == this.INPUT_BUER_ANIMATION_SYNC then
        return selectAnimationState(this, context)
    elseif input == INPUT_RELOAD then
        -- 允许普通换弹主动中断横扫；服务器状态仍由技能按时清理，Lua 换弹状态
        -- 会吞掉这次 state=1，避免控制器把 sweepshoot 重新拉起。
        return this.main_track_states.buer_manual_reload
    end
end

function sweep_state.exit(this, context)
    context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
end

function fast_reload_state.entry(this, context)
    stopExclusiveAnimations(context)
    animation_controller_state.applied_animation_state = 2
    context:runAnimation("reload_fast", context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK), false, PLAY_ONCE_HOLD, 0)
end

function fast_reload_state.update(this, context)
    if getAnimationState(context) ~= 2 then
        context:trigger(this.INPUT_BUER_ANIMATION_SYNC)
    else
        stopBlockedOverlayAnimations(context)
    end
end

function fast_reload_state.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        return this.main_track_states.final
    elseif input == this.INPUT_BUER_ANIMATION_SYNC then
        return selectAnimationState(this, context)
    end
end

function fast_reload_state.exit(this, context)
    context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
end

function manual_reload_state.entry(this, context)
    -- 若从横扫中断进入，标记当前 state=1 已被这次普通换弹消费；控制器不会重播横扫。
    animation_controller_state.applied_animation_state = getAnimationState(context)
    manual_reload_state.ammo_before_reload = context:getAmmoCount()
    if isNoAmmo(context) or not context:hasAmmoToConsume() then
        manual_reload_state.tactical_visual_fill_at = -1
    else
        manual_reload_state.tactical_visual_fill_at = context:getCurrentTimestamp()
            + manual_reload_state.tactical_visual_fill_delay
    end
    stopBlockedOverlayAnimations(context)
    runNormalReloadAnimation(context)
end

function manual_reload_state.update(this, context)
    if context:isStopped(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)) then
        context:trigger(this.INPUT_BUER_MANUAL_RELOAD_DONE)
    end
end

function manual_reload_state.transition(this, context, input)
    if input == INPUT_PUT_AWAY then
        -- 战术换弹在中点前被收枪中断时，不保留视觉满弹覆盖。
        manual_reload_state.tactical_visual_fill_at = -1
        return this.main_track_states.final
    elseif input == this.INPUT_BUER_ANIMATION_SYNC then
        local state = getAnimationState(context)
        if state == 0 then
            -- 横扫状态按时结束时只确认同步，不中断正在播放的普通换弹动画。
            animation_controller_state.applied_animation_state = 0
            return nil
        end
        manual_reload_state.tactical_visual_fill_at = -1
        return selectAnimationState(this, context)
    elseif input == this.INPUT_BUER_MANUAL_RELOAD_DONE then
        return this.main_track_states.idle
    end
end

function animation_controller_state.update(this, context)
    local state = getAnimationState(context)
    if state ~= animation_controller_state.last_animation_state then
        animation_controller_state.last_animation_state = state
        movement_run_state.mode = -1
        movement_walk_state.mode = -1
    end

    -- 如果状态变化发生在 draw 等暂不接收自定义输入的状态中，这里会持续重试，
    -- 直到主轨道真正进入对应的 Lua 特殊状态，而不会因为一次信号丢失而漏播。
    if state ~= animation_controller_state.applied_animation_state then
        context:trigger(this.INPUT_BUER_ANIMATION_SYNC)
    end

    local shot_serial = getScoreInt(context, "%Var_BuerSweepShotSerial%")
    if shot_serial ~= animation_controller_state.last_shot_serial then
        animation_controller_state.last_shot_serial = shot_serial
        if state ~= 0 then
            local track = context:findIdleTrack(GUN_KICK_TRACK_LINE, false)
            context:runAnimation("shoot2", track, true, PLAY_ONCE_STOP, 0)
        end
    end

    if state ~= 0 then
        stopBlockedOverlayAnimations(context)
    end
end

function movement_idle_state.update(this, context)
    if isSpecialAnimationActive(context) then
        -- 静止时不叠加 idle；一旦收到移动输入，默认 transition 会进入 walk。
        context:stopAnimation(context:getTrack(BLENDING_TRACK_LINE, MOVEMENT_TRACK))
    else
        movement_track_states.idle.update(this, context)
    end
end

function movement_run_state.entry(this, context)
    if isSpecialAnimationActive(context) then
        -- 特殊动画期间屏蔽 run_start，并准备改用 walk 动画。
        movement_run_state.mode = -1
        movement_walk_state.mode = -1
    else
        movement_track_states.run.entry(this, context)
    end
end

function movement_run_state.update(this, context)
    if isSpecialAnimationActive(context) then
        -- 玩家仍处于疾跑输入时也只叠加 walk，不播放 run/run_hold。
        movement_track_states.walk.update(this, context)
    else
        movement_track_states.run.update(this, context)
    end
end

function movement_run_state.exit(this, context)
    if isSpecialAnimationActive(context) then
        -- 不播放 run_end，避免它覆盖横扫或快速装填。
        movement_run_state.mode = -1
    else
        movement_track_states.run.exit(this, context)
    end
end

function movement_run_state.transition(this, context, input)
    return movement_track_states.run.transition(this, context, input)
end

function movement_walk_state.entry(this, context)
    movement_walk_state.mode = -1
end

function movement_walk_state.update(this, context)
    -- walk 允许与横扫/快速装填叠加。
    movement_track_states.walk.update(this, context)
end

function movement_walk_state.exit(this, context)
    if isSpecialAnimationActive(context) then
        context:stopAnimation(context:getTrack(BLENDING_TRACK_LINE, MOVEMENT_TRACK))
    else
        movement_track_states.walk.exit(this, context)
    end
end

function movement_walk_state.transition(this, context, input)
    return movement_track_states.walk.transition(this, context, input)
end

function normal.update(this, context)
    local track = context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK)
    local ammo_count = context:getAmmoCount()
    local progress = math.max(0, math.min(1, ammo_count / 5))

    if manual_reload_state.tactical_visual_fill_at ~= -1 then
        if ammo_count > manual_reload_state.ammo_before_reload then
            -- TacZ 已结算真实弹量，后续重新交给实际弹量驱动。
            manual_reload_state.tactical_visual_fill_at = -1
        elseif context:getCurrentTimestamp() >= manual_reload_state.tactical_visual_fill_at then
            -- 战术换弹进行到一半时，新弹巢已装入；提前显示完整的五发弹头。
            progress = 1
        end
    end

    context:setAnimationProgress(track, progress, false)
    context:pauseAnimation(track)

    if (isNoAmmo(context)) then
        context:trigger(this.INPUT_BOLT_CAUGHT)
    end
end

function normal.entry(this, context)
    context:runAnimation("bullet_state", context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK), true, PLAY_ONCE_HOLD, 0)
    this.bolt_caught_states.normal.update(this, context)
end

function normal.transition(this, context, input)
    if (input == this.INPUT_BOLT_CAUGHT) then
        return this.bolt_caught_states.bolt_caught
    end
end

function bolt_caught.entry(this, context)
    -- static_bolt_caught 隐藏弹巢中的五枚弹头。
    context:runAnimation("static_bolt_caught", context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK), true, PLAY_ONCE_HOLD, 0)
end

function bolt_caught.update(this, context)
    if (not isNoAmmo(context)) then
        context:trigger(default.INPUT_BOLT_NORMAL)
    end
end

function bolt_caught.transition(this, context, input)
    if (input == default.INPUT_BOLT_NORMAL) then
        context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, BOLT_CAUGHT_TRACK))
        return this.bolt_caught_states.normal
    end
end

local M = setmetatable({
    main_track_states = setmetatable({
        start = start_state,
        idle = idle_state,
        charge = charge_state,
        inspect = inspect_state,
        final = final_state,
        buer_sweep = sweep_state,
        buer_fast_reload = fast_reload_state,
        buer_manual_reload = manual_reload_state
    }, {__index = main_track_states}),
    movement_track_states = setmetatable({
        idle = movement_idle_state,
        run = movement_run_state,
        walk = movement_walk_state
    }, {__index = movement_track_states}),
    bolt_caught_states = setmetatable({
        normal = normal,
        bolt_caught = bolt_caught
    }, {__index = bolt_caught_states}),
    gun_kick_state = gun_kick_state,
    animation_controller_state = animation_controller_state,
    INPUT_CHARING = "input_charging",
    INPUT_CHARING_EXIT = "input_charging_exit",
    INPUT_BUER_ANIMATION_SYNC = "buer_animation_sync",
    INPUT_BUER_MANUAL_RELOAD_DONE = "buer_manual_reload_done"
}, {__index = default})

function M:initialize(context)
    charge_state.can_charge = true
    manual_reload_state.tactical_visual_fill_at = -1
    manual_reload_state.ammo_before_reload = context:getAmmoCount()
    animation_controller_state.last_animation_state = -1
    animation_controller_state.last_shot_serial = getScoreInt(context, "%Var_BuerSweepShotSerial%")
    animation_controller_state.applied_animation_state = 0
    default.initialize(self, context)
end

function M:states()
    local states = default.states(self)
    table.insert(states, self.animation_controller_state)
    return states
end

return M
